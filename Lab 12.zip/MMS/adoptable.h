#ifndef __ADOPTABLE_H
#define __ADOPTABLE_H

#include "date.h"
#include <string>

class Adoptable {
public:
  virtual bool hasRestrictions(std::string &restrictions);

  void print();

  AdoptableType getType() const;

  bool hasShot() const;

  std::string getFirstName() const;
  std::string getLastName() const;

private:

};

class Turtle : public Adoptable {
public:
};

class Dog : public Adoptable {
public:
};

class Cat : public Adoptable {
public:
};

#endif